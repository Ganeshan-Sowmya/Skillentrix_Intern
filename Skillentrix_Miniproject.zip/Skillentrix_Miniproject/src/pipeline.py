"""
Master Predictive Maintenance Pipeline Runner
Orchestrates:
1. Synthetic industrial sensor data generation
2. Future prediction window labeling (leakage-free lead time target)
3. Causal rolling statistics & lag feature engineering
4. Imbalanced model training & multi-model benchmark evaluation
5. Artifact persistence
"""

import os
import time
import pandas as pd
from src.data_generator import generate_industrial_dataset
from src.labeling import label_failure_prediction_window
from src.feature_engineering import create_leakage_free_features
from src.model_training import train_and_evaluate_models

def run_predictive_maintenance_pipeline(
    num_machines: int = 10,
    days: int = 180,
    prediction_window_hours: int = 24,
    temporal_split_ratio: float = 0.75,
    force_regenerate: bool = True
):
    print("=" * 75)
    print("  PREDICTIVE MAINTENANCE FOR INDUSTRIAL EQUIPMENT PIPELINE")
    print("=" * 75)
    start_total = time.time()
    
    data_dir_raw = "data/raw"
    data_dir_processed = "data/processed"
    os.makedirs(data_dir_processed, exist_ok=True)
    
    # Step 1: Collect / Generate Sensor Telemetry & Maintenance Logs
    print("\n>>> STEP 1: Generating Multi-Machine Telemetry & Maintenance History...")
    df_telemetry, df_maintenance, df_machines = generate_industrial_dataset(
        num_machines=num_machines,
        days=days,
        output_dir=data_dir_raw
    )
    
    # Step 2: Define Prediction Window & Label Observations
    print(f"\n>>> STEP 2: Defining {prediction_window_hours}-hour Failure Prediction Window...")
    df_labeled = label_failure_prediction_window(
        df_telemetry=df_telemetry,
        df_maintenance=df_maintenance,
        prediction_window_hours=prediction_window_hours
    )
    
    # Step 3: Backward-Only Causal Feature Engineering (Zero Future Leakage)
    print("\n>>> STEP 3: Engineering Backward-Looking Rolling Stats, Lags, and Stress Metrics...")
    df_features = create_leakage_free_features(df_labeled)
    
    processed_features_path = os.path.join(data_dir_processed, "features_engineered.csv")
    df_features.to_csv(processed_features_path, index=False)
    print(f"[Pipeline] Saved processed feature matrix ({df_features.shape[0]:,} rows x {df_features.shape[1]} cols) -> {processed_features_path}")
    
    # Step 4 & 5: Model Training, Imbalance Handling & Rigorous Evaluation
    print("\n>>> STEP 4 & 5: Training Classifiers with Imbalance Weighting & Evaluating PR-AUC...")
    summary = train_and_evaluate_models(
        df_features=df_features,
        target_col='failure_in_window',
        temporal_split_ratio=temporal_split_ratio,
        models_dir="models"
    )
    
    elapsed = time.time() - start_total
    print("\n" + "=" * 75)
    print(f" PIPELINE COMPLETE in {elapsed:.1f}s | Champion Model: {summary['champion_model_name']}")
    champ_stats = summary['models_benchmarks'][summary['champion_model_name']]['default_threshold_metrics']
    print(f" Test PR-AUC: {champ_stats['pr_auc']:.4f} | Recall: {champ_stats['recall']*100:.1f}% | Precision: {champ_stats['precision']*100:.1f}%")
    print(f" False Alarms: {champ_stats['confusion_matrix']['false_positives_false_alarms']} | Net Savings: ${champ_stats['cost_analysis']['net_savings_usd']:,.2f}")
    print("=" * 75 + "\n")
    
    return summary

if __name__ == "__main__":
    run_predictive_maintenance_pipeline()
