"""
Model Evaluation and Metrics Module
Calculates Recall, Precision, PR-AUC, ROC-AUC, False Alarms, Confusion Matrix,
and Operational Cost-Benefit Analysis for industrial predictive maintenance.
"""

import numpy as np
import pandas as pd
from typing import Dict, Any, Tuple
from sklearn.metrics import (
    precision_score, recall_score, f1_score, fbeta_score,
    roc_auc_score, average_precision_score, confusion_matrix,
    precision_recall_curve, roc_curve
)

def evaluate_classifier_predictions(
    y_true: np.ndarray,
    y_pred_proba: np.ndarray,
    threshold: float = 0.5,
    cost_unplanned_failure: float = 10000.0,
    cost_preventive_inspection: float = 1200.0,
    cost_false_alarm: float = 350.0
) -> Dict[str, Any]:
    """
    Comprehensive evaluation for predictive maintenance:
    - Standard classification metrics: Precision, Recall, F1, F2 (recall weighted)
    - PR-AUC (Precision-Recall Area Under Curve - essential for imbalanced data)
    - ROC-AUC
    - False Alarms (False Positives) count & False Alarm Rate
    - Missed Failures (False Negatives) count
    - Operational Cost Analysis ($ saved vs run-to-failure strategy)
    """
    y_pred = (y_pred_proba >= threshold).astype(int)
    
    # Confusion matrix elements
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()
    
    # Core classification metrics
    precision = precision_score(y_true, y_pred, zero_division=0)
    recall = recall_score(y_true, y_pred, zero_division=0)
    f1 = f1_score(y_true, y_pred, zero_division=0)
    f2 = fbeta_score(y_true, y_pred, beta=2.0, zero_division=0)
    
    # Area under curves
    try:
        roc_auc = roc_auc_score(y_true, y_pred_proba)
    except Exception:
        roc_auc = 0.5
        
    try:
        pr_auc = average_precision_score(y_true, y_pred_proba)
    except Exception:
        pr_auc = 0.0
        
    # Rates
    false_alarm_rate = fp / (fp + tn) if (fp + tn) > 0 else 0.0
    miss_rate = fn / (fn + tp) if (fn + tp) > 0 else 0.0
    
    # Financial Cost Analysis ($)
    # Scenario A: Run-to-Failure baseline (no model) -> all failures become catastrophic breakdowns
    total_failures_in_eval = int(tp + fn)
    baseline_cost_run_to_failure = total_failures_in_eval * cost_unplanned_failure
    
    # Scenario B: Predictive Maintenance model
    # TP: Intercepted in time -> planned preventive repair
    # FP: False alarm inspection cost
    # FN: Catastrophic breakdown
    # TN: No action, no extra cost
    model_operational_cost = (
        (tp * cost_preventive_inspection) + 
        (fp * cost_false_alarm) + 
        (fn * cost_unplanned_failure)
    )
    
    net_savings = max(0.0, baseline_cost_run_to_failure - model_operational_cost)
    roi_percent = (net_savings / model_operational_cost * 100.0) if model_operational_cost > 0 else 0.0

    # Curves for frontend plotting
    p_curve, r_curve, pr_thresholds = precision_recall_curve(y_true, y_pred_proba)
    fpr_curve, tpr_curve, roc_thresholds = roc_curve(y_true, y_pred_proba)
    
    # Downsample curves to 25 points each for efficient JSON serialization and crisp charting
    step_pr = max(1, len(p_curve) // 25)
    step_roc = max(1, len(fpr_curve) // 25)

    return {
        "threshold": round(float(threshold), 3),
        "precision": round(float(precision), 4),
        "recall": round(float(recall), 4),
        "f1_score": round(float(f1), 4),
        "f2_score": round(float(f2), 4),
        "pr_auc": round(float(pr_auc), 4),
        "roc_auc": round(float(roc_auc), 4),
        "confusion_matrix": {
            "true_negatives": int(tn),
            "false_positives_false_alarms": int(fp),
            "false_negatives_missed": int(fn),
            "true_positives_detected": int(tp)
        },
        "false_alarm_rate": round(float(false_alarm_rate), 4),
        "miss_rate": round(float(miss_rate), 4),
        "cost_analysis": {
            "baseline_run_to_failure_cost_usd": round(float(baseline_cost_run_to_failure), 2),
            "model_operational_cost_usd": round(float(model_operational_cost), 2),
            "net_savings_usd": round(float(net_savings), 2),
            "roi_percent": round(float(roi_percent), 1)
        },
        "pr_curve_sample": {
            "recall": [round(float(x), 4) for x in r_curve[::step_pr]],
            "precision": [round(float(x), 4) for x in p_curve[::step_pr]]
        },
        "roc_curve_sample": {
            "fpr": [round(float(x), 4) for x in fpr_curve[::step_roc]],
            "tpr": [round(float(x), 4) for x in tpr_curve[::step_roc]]
        }
    }

def find_optimal_operational_threshold(
    y_true: np.ndarray,
    y_pred_proba: np.ndarray,
    cost_unplanned_failure: float = 10000.0,
    cost_preventive_inspection: float = 1200.0,
    cost_false_alarm: float = 350.0
) -> float:
    """
    Finds the decision threshold that minimizes total industrial operational cost.
    """
    best_threshold = 0.5
    min_cost = float('inf')
    
    for thresh in np.linspace(0.1, 0.9, 81):
        y_pred = (y_pred_proba >= thresh).astype(int)
        tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()
        cost = (tp * cost_preventive_inspection) + (fp * cost_false_alarm) + (fn * cost_unplanned_failure)
        if cost < min_cost:
            min_cost = cost
            best_threshold = thresh
            
    return round(float(best_threshold), 2)
