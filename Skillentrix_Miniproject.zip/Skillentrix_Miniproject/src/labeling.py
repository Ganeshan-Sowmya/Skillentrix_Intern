"""
Failure Prediction Window Labeling Module
Defines future prediction horizon (e.g. 24h lead time) and labels observations
without data leakage.
"""

import pandas as pd
import numpy as np

def label_failure_prediction_window(
    df_telemetry: pd.DataFrame,
    df_maintenance: pd.DataFrame,
    prediction_window_hours: int = 24,
    lead_time_min_hours: int = 0
) -> pd.DataFrame:
    """
    Labels each telemetry observation with a binary target:
    `failure_in_window`: 1 if a failure breakdown occurs within the next 
    (lead_time_min_hours, prediction_window_hours] window for this machine, else 0.
    
    Parameters:
    -----------
    df_telemetry: DataFrame with ['timestamp', 'machine_id', ...]
    df_maintenance: DataFrame with ['timestamp', 'machine_id', 'maintenance_type', ...]
    prediction_window_hours: Prediction lead time horizon W (default 24h)
    lead_time_min_hours: Minimum lead time offset (default 0h)
    
    Returns:
    --------
    DataFrame with added 'failure_in_window' and 'hours_to_next_failure' columns.
    """
    df_telemetry = df_telemetry.copy()
    df_telemetry['timestamp'] = pd.to_datetime(df_telemetry['timestamp'])
    
    # Filter only unplanned failure breakdown events
    df_failures = df_maintenance[df_maintenance['maintenance_type'] == 'UNPLANNED_BREAKDOWN'].copy()
    df_failures['timestamp'] = pd.to_datetime(df_failures['timestamp'])
    
    # Sort for safety
    df_telemetry = df_telemetry.sort_values(by=['machine_id', 'timestamp']).reset_index(drop=True)
    
    # Initialize target columns
    df_telemetry['failure_in_window'] = 0
    df_telemetry['hours_to_next_failure'] = 9999.0
    
    for machine_id, m_failures in df_failures.groupby('machine_id'):
        machine_mask = (df_telemetry['machine_id'] == machine_id)
        machine_timestamps = df_telemetry.loc[machine_mask, 'timestamp'].values
        
        failure_times = m_failures['timestamp'].values
        
        if len(failure_times) == 0:
            continue
            
        # For each telemetry timestamp of this machine, find time delta to subsequent failure
        for f_time in failure_times:
            # Time delta in hours: (f_time - timestamp) in nanoseconds / (3600 * 1e9)
            time_diff_hours = (pd.to_datetime(f_time) - df_telemetry.loc[machine_mask, 'timestamp']).dt.total_seconds() / 3600.0
            
            # Observations where failure is in future within the window:
            # lead_time_min_hours <= time_diff_hours <= prediction_window_hours
            in_window_mask = machine_mask & (time_diff_hours >= lead_time_min_hours) & (time_diff_hours <= prediction_window_hours)
            df_telemetry.loc[in_window_mask, 'failure_in_window'] = 1
            
            # Track minimum hours to next failure
            future_mask = machine_mask & (time_diff_hours >= 0)
            current_min = df_telemetry.loc[future_mask, 'hours_to_next_failure']
            updated_min = np.minimum(current_min, time_diff_hours[future_mask])
            df_telemetry.loc[future_mask, 'hours_to_next_failure'] = updated_min
            
    print(f"[Labeling] Prediction Window: {prediction_window_hours} hours.")
    pos_count = int(df_telemetry['failure_in_window'].sum())
    total_count = len(df_telemetry)
    pos_rate = (pos_count / total_count) * 100.0
    print(f"[Labeling] Target distribution: {pos_count:,} positive failure-window samples out of {total_count:,} ({pos_rate:.2f}% positive rate - imbalanced)")
    
    return df_telemetry
