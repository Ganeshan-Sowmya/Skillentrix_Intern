"""
Feature Engineering Pipeline for Predictive Maintenance
Constructs rolling statistics, lag features, volatility indicators, and operational ratios.
Guarantees NO future data leakage (strictly backward-looking rolling and lag operations).
"""

import pandas as pd
import numpy as np
from typing import List, Tuple

def create_leakage_free_features(
    df: pd.DataFrame,
    sensor_cols: List[str] = ['temperature', 'vibration', 'pressure'],
    rolling_windows: List[int] = [3, 12, 24]
) -> pd.DataFrame:
    """
    Computes strictly backward-looking temporal features per machine:
    - Rolling means, std deviations (volatility/instability), min, max
    - Lagged sensor values (1h, 3h lags)
    - Short-term rate of change (deltas)
    - Cross-sensor domain indicators (e.g. vibration-to-load ratio)
    - Operating fatigue indicators
    
    Guarantees no future leakage by:
    1. Grouping strictly by machine_id
    2. Sorting strictly ascending by timestamp
    3. Using closed='right' causal rolling windows with no forward shifts
    """
    df = df.copy()
    df['timestamp'] = pd.to_datetime(df['timestamp'])
    df = df.sort_values(by=['machine_id', 'timestamp']).reset_index(drop=True)
    
    feature_dfs = []
    
    for machine_id, group in df.groupby('machine_id', sort=False):
        group = group.copy()
        
        # 1. Base Sensor Rolling Statistics
        for col in sensor_cols:
            for w in rolling_windows:
                # Rolling mean (past w hours inclusive of current)
                group[f"{col}_roll_mean_{w}h"] = group[col].rolling(window=w, min_periods=1).mean()
                # Rolling std (volatility/jitter)
                group[f"{col}_roll_std_{w}h"] = group[col].rolling(window=w, min_periods=1).std().fillna(0.0)
                # Rolling max
                group[f"{col}_roll_max_{w}h"] = group[col].rolling(window=w, min_periods=1).max()
                # Rolling min
                group[f"{col}_roll_min_{w}h"] = group[col].rolling(window=w, min_periods=1).min()
                # Peak-to-peak spread in window
                group[f"{col}_roll_range_{w}h"] = group[f"{col}_roll_max_{w}h"] - group[f"{col}_roll_min_{w}h"]
            
            # 2. Lag Features (values from 1h and 3h ago)
            group[f"{col}_lag_1h"] = group[col].shift(1).bfill()
            group[f"{col}_lag_3h"] = group[col].shift(3).bfill()
            
            # 3. Differencing / Rate of Change (derivative)
            group[f"{col}_diff_1h"] = group[col] - group[f"{col}_lag_1h"]
            group[f"{col}_diff_3h"] = group[col] - group[f"{col}_lag_3h"]
            
            # Acceleration of degradation (second derivative)
            group[f"{col}_accel_3h"] = group[f"{col}_diff_1h"] - (group[f"{col}_lag_1h"] - group[f"{col}_lag_3h"]) / 2.0
            
        # 4. Cross-Sensor Domain Features
        # Vibration per unit operational load: high vibration at low load indicates severe bearing play
        load_safe = group['operational_load'].replace(0, 0.01)
        group['vib_to_load_ratio'] = group['vibration'] / load_safe
        
        # Thermal stress indicator: temp difference from ambient
        group['temp_above_ambient'] = group['temperature'] - group['ambient_temp']
        
        # Pressure instability: deviation from rolling baseline
        group['pressure_deviation_24h'] = group['pressure'] - group['pressure_roll_mean_24h']
        
        # 5. Machine Age & Wear Fatigue Features
        # Logarithmic fatigue stress
        group['service_stress_index'] = np.log1p(group['hours_since_last_service']) * (group['vibration_roll_mean_12h'])
        
        # Lubrication depletion rate
        group['lubrication_risk'] = 100.0 - group['lubrication_level']
        
        feature_dfs.append(group)
        
    df_engineered = pd.concat(feature_dfs, ignore_index=True)
    
    # Fill any edge NaNs cleanly with 0
    df_engineered = df_engineered.fillna(0.0)
    
    print(f"[Feature Engineering] Generated {df_engineered.shape[1]} total columns across {len(df_engineered):,} records.")
    return df_engineered

def get_model_feature_columns() -> List[str]:
    """
    Returns the list of engineered predictor feature names used for model training.
    Excludes identifiers, timestamps, raw event strings, and target labels.
    """
    sensor_cols = ['temperature', 'vibration', 'pressure']
    rolling_windows = [3, 12, 24]
    
    features = [
        'temperature', 'vibration', 'pressure', 'operational_load',
        'ambient_temp', 'lubrication_level', 'hours_since_last_service'
    ]
    
    for col in sensor_cols:
        for w in rolling_windows:
            features.extend([
                f"{col}_roll_mean_{w}h",
                f"{col}_roll_std_{w}h",
                f"{col}_roll_max_{w}h",
                f"{col}_roll_min_{w}h",
                f"{col}_roll_range_{w}h"
            ])
        features.extend([
            f"{col}_lag_1h",
            f"{col}_lag_3h",
            f"{col}_diff_1h",
            f"{col}_diff_3h",
            f"{col}_accel_3h"
        ])
        
    features.extend([
        'vib_to_load_ratio',
        'temp_above_ambient',
        'pressure_deviation_24h',
        'service_stress_index',
        'lubrication_risk'
    ])
    
    return features
