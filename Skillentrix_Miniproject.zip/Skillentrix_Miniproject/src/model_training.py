"""
Classification Model Training with Imbalance Handling
Trains and benchmarks multiple ML classifiers on temporal train-test splits.
Handles rare failure events using class weighting and cost optimization.
"""

import os
import json
import joblib
import numpy as np
import pandas as pd
from typing import Dict, Any, Tuple

from sklearn.ensemble import RandomForestClassifier, HistGradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from src.feature_engineering import get_model_feature_columns
from src.evaluation import evaluate_classifier_predictions, find_optimal_operational_threshold

def train_and_evaluate_models(
    df_features: pd.DataFrame,
    target_col: str = 'failure_in_window',
    temporal_split_ratio: float = 0.75,
    models_dir: str = "models"
) -> Dict[str, Any]:
    """
    Executes model training and comparison:
    1. Temporal split (older 75% for train, latest 25% for test - zero future leakage)
    2. Model training with class_weight='balanced' to handle rare failure anomalies
    3. Evaluation across models (Precision, Recall, PR-AUC, False Alarms)
    4. Optimal decision threshold calibration
    5. Feature importance extraction
    6. Serialization of best model artifact
    """
    os.makedirs(models_dir, exist_ok=True)
    feature_cols = get_model_feature_columns()
    
    # Verify features exist in dataframe
    valid_features = [c for c in feature_cols if c in df_features.columns]
    print(f"[Model Training] Selected {len(valid_features)} valid predictor features.")
    
    # Temporal Train/Test split: sort by timestamp
    df_sorted = df_features.sort_values(by='timestamp').reset_index(drop=True)
    split_idx = int(len(df_sorted) * temporal_split_ratio)
    split_timestamp = df_sorted.loc[split_idx, 'timestamp']
    
    train_df = df_sorted.iloc[:split_idx].copy()
    test_df = df_sorted.iloc[split_idx:].copy()
    
    X_train = train_df[valid_features].values
    y_train = train_df[target_col].values
    
    X_test = test_df[valid_features].values
    y_test = test_df[target_col].values
    
    train_pos = int(y_train.sum())
    test_pos = int(y_test.sum())
    print(f"[Model Training] Temporal split at {split_timestamp}:")
    print(f"  - Train: {len(X_train):,} samples, {train_pos:,} failure windows ({train_pos/len(X_train)*100:.2f}%)")
    print(f"  - Test:  {len(X_test):,} samples, {test_pos:,} failure windows ({test_pos/len(X_test)*100:.2f}%)")
    
    # Candidate Models definition
    candidate_models = {
        "RandomForest": RandomForestClassifier(
            n_estimators=100,
            max_depth=12,
            min_samples_split=10,
            class_weight='balanced',
            random_state=42,
            n_jobs=-1
        ),
        "HistGradientBoosting": HistGradientBoostingClassifier(
            max_iter=100,
            max_depth=8,
            class_weight='balanced',
            random_state=42
        ),
        "LogisticRegression": Pipeline([
            ('scaler', StandardScaler()),
            ('clf', LogisticRegression(class_weight='balanced', max_iter=1000, random_state=42))
        ])
    }
    
    model_results = {}
    fitted_models = {}
    
    best_model_name = None
    best_pr_auc = -1.0
    
    for name, model in candidate_models.items():
        print(f"[Model Training] Fitting {name} with imbalance weighting...")
        model.fit(X_train, y_train)
        fitted_models[name] = model
        
        # Predict probabilities for positive class (failure in window)
        y_test_proba = model.predict_proba(X_test)[:, 1]
        
        # Standard evaluation at default 0.5 threshold
        eval_metrics = evaluate_classifier_predictions(y_test, y_test_proba, threshold=0.5)
        
        # Find optimal operational threshold
        opt_thresh = find_optimal_operational_threshold(y_test, y_test_proba)
        opt_eval = evaluate_classifier_predictions(y_test, y_test_proba, threshold=opt_thresh)
        
        model_results[name] = {
            "default_threshold_metrics": eval_metrics,
            "optimal_threshold": opt_thresh,
            "optimal_threshold_metrics": opt_eval
        }
        
        pr_auc = eval_metrics["pr_auc"]
        print(f"  -> {name} | PR-AUC: {pr_auc:.4f} | Recall: {eval_metrics['recall']:.4f} | Precision: {eval_metrics['precision']:.4f} | False Alarms: {eval_metrics['confusion_matrix']['false_positives_false_alarms']}")
        
        if pr_auc > best_pr_auc:
            best_pr_auc = pr_auc
            best_model_name = name
            
    print(f"\n[Model Training] Champion Model Selected: {best_model_name} (PR-AUC: {best_pr_auc:.4f})")
    champion_model = fitted_models[best_model_name]
    
    # Feature Importances extraction
    feature_importances = []
    if hasattr(champion_model, "feature_importances_"):
        raw_importances = champion_model.feature_importances_
        for feat, imp in zip(valid_features, raw_importances):
            feature_importances.append({"feature": feat, "importance": round(float(imp), 4)})
        feature_importances = sorted(feature_importances, key=lambda x: x["importance"], reverse=True)[:15]
    elif hasattr(champion_model, "named_steps") and hasattr(champion_model.named_steps['clf'], "coef_"):
        coefs = np.abs(champion_model.named_steps['clf'].coef_[0])
        for feat, imp in zip(valid_features, coefs):
            feature_importances.append({"feature": feat, "importance": round(float(imp), 4)})
        feature_importances = sorted(feature_importances, key=lambda x: x["importance"], reverse=True)[:15]
        
    # Serialize artifacts
    best_model_path = os.path.join(models_dir, "best_model.joblib")
    joblib.dump(champion_model, best_model_path)
    
    # Metadata and summary
    summary = {
        "champion_model_name": best_model_name,
        "selected_features": valid_features,
        "train_samples": len(X_train),
        "test_samples": len(X_test),
        "train_positive_rate": round(train_pos / len(X_train), 4),
        "test_positive_rate": round(test_pos / len(X_test), 4),
        "models_benchmarks": model_results,
        "top_feature_importances": feature_importances,
        "optimal_operational_threshold": model_results[best_model_name]["optimal_threshold"]
    }
    
    summary_path = os.path.join(models_dir, "metrics_summary.json")
    with open(summary_path, "w") as f:
        json.dump(summary, f, indent=2)
        
    features_path = os.path.join(models_dir, "feature_columns.json")
    with open(features_path, "w") as f:
        json.dump(valid_features, f, indent=2)
        
    print(f"[Model Training] Artifacts saved:")
    print(f"  - Model: {best_model_path}")
    print(f"  - Summary Metrics: {summary_path}")
    print(f"  - Feature Columns: {features_path}")
    
    return summary
