"""
Industrial Equipment Telemetry & Maintenance Data Generator
Generates realistic multivariate time-series data for industrial machines with:
- Normal operational dynamics (load cycles, ambient temperature cycles)
- Physically grounded degradation patterns (bearing wear, thermal runaway, seal leakage)
- Maintenance events (preventive servicing and catastrophic breakdowns)
"""

import os
import numpy as np
import pandas as pd
from datetime import datetime, timedelta

def generate_industrial_dataset(
    num_machines: int = 10,
    days: int = 180,
    sampling_interval_hours: int = 1,
    random_seed: int = 42,
    output_dir: str = "data/raw"
):
    """
    Generate synthetic sensor telemetry, machine metadata, and maintenance logs.
    """
    np.random.seed(random_seed)
    os.makedirs(output_dir, exist_ok=True)
    
    total_hours = days * 24
    start_time = datetime(2025, 1, 1, 0, 0, 0)
    
    machine_types = [
        {"model": "CNC-Spindle-X5", "type": "CNC Mill", "base_temp": 68.0, "base_vib": 2.2, "base_press": 95.0},
        {"model": "HydroPress-Pro-80", "type": "Hydraulic Press", "base_temp": 62.0, "base_vib": 1.8, "base_press": 140.0},
        {"model": "CentriPump-HP400", "type": "Centrifugal Pump", "base_temp": 58.0, "base_vib": 3.1, "base_press": 110.0},
        {"model": "AirComp-Vortex-30", "type": "Air Compressor", "base_temp": 72.0, "base_vib": 2.5, "base_press": 125.0},
        {"model": "Turbine-Gen-2500", "type": "Turbine Generator", "base_temp": 75.0, "base_vib": 1.5, "base_press": 160.0}
    ]
    
    telemetry_records = []
    maintenance_records = []
    machine_records = []
    
    for m_idx in range(1, num_machines + 1):
        machine_id = f"M-{100 + m_idx}"
        profile = machine_types[(m_idx - 1) % len(machine_types)]
        
        # Metadata
        install_age_days = np.random.randint(180, 1500)
        machine_records.append({
            "machine_id": machine_id,
            "machine_type": profile["type"],
            "model": profile["model"],
            "install_date": (start_time - timedelta(days=install_age_days)).strftime("%Y-%m-%d"),
            "initial_operating_hours": np.random.randint(2000, 15000),
            "rated_power_kw": np.random.choice([45, 75, 110, 160, 250]),
            "location_zone": f"Zone-{chr(65 + (m_idx % 4))}"
        })
        
        # State tracking per machine
        cumulative_hours = machine_records[-1]["initial_operating_hours"]
        hours_since_last_service = np.random.randint(50, 400)
        
        # Degradation accumulators
        bearing_wear = 0.0
        thermal_dissipation_loss = 0.0
        seal_leakage = 0.0
        is_failing = False
        hours_until_failure = 0
        failure_type = None
        
        # Plan 2 to 4 failure episodes over the 180 days for this machine
        num_episodes = np.random.randint(2, 5)
        # Random failure occurrence points
        failure_hours = sorted(np.random.choice(range(240, total_hours - 120), size=num_episodes, replace=False))
        # Ensure minimum distance between failures
        valid_failure_hours = []
        last_h = -999
        for fh in failure_hours:
            if fh - last_h > 400:
                valid_failure_hours.append(fh)
                last_h = fh
                
        # Scheduled preventive maintenance events
        preventive_maintenance_hours = list(range(500, total_hours, 650))
        
        current_failure_target = valid_failure_hours.pop(0) if valid_failure_hours else None
        
        for h in range(total_hours):
            current_time = start_time + timedelta(hours=h)
            cumulative_hours += 1
            hours_since_last_service += 1
            
            # Diurnal ambient temperature cycle (colder at night, warmer at 2pm)
            hour_of_day = current_time.hour
            ambient_temp = 22.0 + 7.0 * np.sin((hour_of_day - 8) * np.pi / 12) + np.random.normal(0, 0.6)
            
            # Machine operational load (cycles between 60% and 100% capacity)
            operational_load = 0.75 + 0.20 * np.sin(h * 2 * np.pi / 24) + np.random.normal(0, 0.04)
            operational_load = np.clip(operational_load, 0.4, 1.05)
            
            # Check if entering degradation lead-up to failure (e.g. 48 hours prior)
            is_failure_imminent = False
            time_to_failure = 9999
            
            if current_failure_target is not None:
                lead_time = current_failure_target - h
                if 0 <= lead_time <= 48:
                    is_failure_imminent = True
                    time_to_failure = lead_time
                    # Ramp up degradation based on failure mode
                    # Progress from 0 at 48h to 1.0 at 0h
                    progression = (48 - lead_time) / 48.0
                    bearing_wear += 0.05 * progression + np.random.uniform(0.01, 0.04)
                    thermal_dissipation_loss += 0.04 * progression + np.random.uniform(0.01, 0.03)
                    seal_leakage += 0.03 * progression + np.random.uniform(0.01, 0.03)
            
            # Check if failure occurs right now
            event_type = "NORMAL"
            if current_failure_target is not None and h == current_failure_target:
                event_type = "FAILURE_BREAKDOWN"
                f_mode = np.random.choice(["BEARING_SEIZURE", "THERMAL_RUNAWAY", "HYDRAULIC_SEAL_BLOWOUT"])
                maintenance_records.append({
                    "machine_id": machine_id,
                    "timestamp": current_time.strftime("%Y-%m-%d %H:%M:%S"),
                    "maintenance_type": "UNPLANNED_BREAKDOWN",
                    "failure_mode": f_mode,
                    "component_replaced": f_mode.replace("_", " ").title(),
                    "downtime_hours": np.random.randint(8, 24),
                    "repair_cost_usd": np.random.randint(6000, 15000)
                })
                # Reset degradation after emergency maintenance
                bearing_wear = 0.0
                thermal_dissipation_loss = 0.0
                seal_leakage = 0.0
                hours_since_last_service = 0
                current_failure_target = valid_failure_hours.pop(0) if valid_failure_hours else None
            
            # Routine maintenance check
            elif h in preventive_maintenance_hours:
                event_type = "PREVENTIVE_MAINTENANCE"
                maintenance_records.append({
                    "machine_id": machine_id,
                    "timestamp": current_time.strftime("%Y-%m-%d %H:%M:%S"),
                    "maintenance_type": "ROUTINE_PREVENTIVE",
                    "failure_mode": "NONE",
                    "component_replaced": "Lubrication & Filter Pack",
                    "downtime_hours": 3,
                    "repair_cost_usd": 850
                })
                bearing_wear = max(0.0, bearing_wear - 0.5)
                thermal_dissipation_loss = 0.0
                seal_leakage = max(0.0, seal_leakage - 0.3)
                hours_since_last_service = 0
            
            # Physical Sensor Simulation
            # 1. Temperature: depends on base, load, ambient temp, thermal loss, and micro-noise
            temp_reading = (
                profile["base_temp"] 
                + 12.0 * (operational_load - 0.75) 
                + 0.35 * (ambient_temp - 22.0)
                + 18.0 * thermal_dissipation_loss
                + np.random.normal(0, 0.8)
            )
            
            # 2. Vibration (RMS velocity in mm/s): increases with load, hours, and bearing wear
            vibration_reading = (
                profile["base_vib"] 
                * (0.85 + 0.3 * operational_load)
                * (1.0 + 0.00002 * hours_since_last_service)
                + 4.5 * (bearing_wear ** 1.3)
                + np.random.normal(0, 0.15)
            )
            vibration_reading = max(0.2, vibration_reading)
            
            # 3. Pressure (PSI): drops or spikes erratically when seal degraded
            pressure_reading = (
                profile["base_press"]
                * (0.95 + 0.1 * operational_load)
                - 25.0 * seal_leakage
                + np.random.normal(0, 1.2)
            )
            
            # 4. Lubrication Quality (0 to 100%): slowly drops with operating hours
            lubrication_level = max(5.0, 100.0 - (hours_since_last_service * 0.12) - (bearing_wear * 15.0) + np.random.normal(0, 0.5))

            telemetry_records.append({
                "timestamp": current_time.strftime("%Y-%m-%d %H:%M:%S"),
                "machine_id": machine_id,
                "temperature": round(float(temp_reading), 2),
                "vibration": round(float(vibration_reading), 3),
                "pressure": round(float(pressure_reading), 2),
                "operational_load": round(float(operational_load), 3),
                "ambient_temp": round(float(ambient_temp), 2),
                "lubrication_level": round(float(lubrication_level), 1),
                "operating_hours": cumulative_hours,
                "hours_since_last_service": hours_since_last_service,
                "raw_event_type": event_type
            })

    df_telemetry = pd.DataFrame(telemetry_records)
    df_maintenance = pd.DataFrame(maintenance_records)
    df_machines = pd.DataFrame(machine_records)
    
    # Save CSVs
    telemetry_path = os.path.join(output_dir, "sensor_telemetry.csv")
    maintenance_path = os.path.join(output_dir, "maintenance_history.csv")
    machines_path = os.path.join(output_dir, "machine_metadata.csv")
    
    df_telemetry.to_csv(telemetry_path, index=False)
    df_maintenance.to_csv(maintenance_path, index=False)
    df_machines.to_csv(machines_path, index=False)
    
    print(f"[Data Generator] Successfully generated:")
    print(f"  - Telemetry: {len(df_telemetry):,} records -> {telemetry_path}")
    print(f"  - Maintenance events: {len(df_maintenance):,} logs -> {maintenance_path}")
    print(f"  - Machines: {len(df_machines)} units -> {machines_path}")
    
    return df_telemetry, df_maintenance, df_machines

if __name__ == "__main__":
    generate_industrial_dataset()
