"""
Integration and End-to-End System Tests
Tests:
1. Feature matrix consistency
2. Model prediction shape and probabilities
3. Flask REST API endpoints and responses
"""

import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import unittest
import json
from app import app, load_artifacts

class TestPredictiveMaintenanceSystem(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        load_artifacts()
        cls.client = app.test_client()

    def test_homepage_render(self):
        response = self.client.get("/")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"SENTINEL-AI", response.data)

    def test_api_fleet(self):
        response = self.client.get("/api/fleet")
        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        self.assertIn("summary", data)
        self.assertIn("machines", data)
        self.assertEqual(len(data["machines"]), 10)
        self.assertIn("failure_risk_pct", data["machines"][0])

    def test_api_telemetry(self):
        response = self.client.get("/api/telemetry/M-101")
        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        self.assertEqual(data["machine_id"], "M-101")
        self.assertTrue(len(data["timestamps"]) > 0)
        self.assertTrue(len(data["vibration"]) > 0)
        self.assertTrue(len(data["temperature"]) > 0)
        self.assertTrue(len(data["pressure"]) > 0)

    def test_api_predict_nominal(self):
        payload = {
            "vibration": 2.1,
            "temperature": 65.0,
            "pressure": 110.0,
            "operational_load": 0.8,
            "hours_since_last_service": 100,
            "lubrication_level": 95.0
        }
        response = self.client.post(
            "/api/predict",
            data=json.dumps(payload),
            content_type="application/json"
        )
        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        self.assertIn("failure_risk_pct", data)
        self.assertEqual(data["status"], "HEALTHY")
        self.assertLess(data["failure_risk_pct"], 30.0)

    def test_api_predict_degraded(self):
        payload = {
            "vibration": 7.5,
            "temperature": 94.0,
            "pressure": 90.0,
            "operational_load": 0.95,
            "hours_since_last_service": 650,
            "lubrication_level": 20.0
        }
        response = self.client.post(
            "/api/predict",
            data=json.dumps(payload),
            content_type="application/json"
        )
        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        self.assertIn("failure_risk_pct", data)
        self.assertIn(data["status"], ["WARNING", "CRITICAL"])
        self.assertGreater(data["failure_risk_pct"], 50.0)

    def test_api_metrics(self):
        response = self.client.get("/api/metrics")
        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        self.assertIn("champion_model_name", data)
        self.assertIn("models_benchmarks", data)
        self.assertIn("top_feature_importances", data)

    def test_api_alerts(self):
        response = self.client.get("/api/alerts")
        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        self.assertIn("alerts", data)

    def test_api_anomaly_injection_and_reset(self):
        # Inject anomaly
        inject_res = self.client.post(
            "/api/inject_anomaly",
            data=json.dumps({"machine_id": "M-105", "anomaly_type": "BEARING_DEGRADATION"}),
            content_type="application/json"
        )
        self.assertEqual(inject_res.status_code, 200)

        # Reset machine
        reset_res = self.client.post(
            "/api/reset_machine",
            data=json.dumps({"machine_id": "M-105"}),
            content_type="application/json"
        )
        self.assertEqual(reset_res.status_code, 200)

if __name__ == "__main__":
    unittest.main()
