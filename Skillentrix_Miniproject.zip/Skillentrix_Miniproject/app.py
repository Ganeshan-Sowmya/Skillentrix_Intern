"""
Predictive Maintenance Monitoring Server (Flask)
Serves SCADA-grade real-time monitoring view, alert triggers,
interactive what-if simulation, and model performance metrics.
"""

import os
import json
import joblib
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from flask import Flask, render_template, jsonify, request

app = Flask(__name__)

# Paths
MODELS_DIR = "models"
DATA_RAW_DIR = "data/raw"
DATA_PROCESSED_DIR = "data/processed"

MODEL_PATH = os.path.join(MODELS_DIR, "best_model.joblib")
METRICS_PATH = os.path.join(MODELS_DIR, "metrics_summary.json")
FEATURES_PATH = os.path.join(MODELS_DIR, "feature_columns.json")

# In-memory global state
model = None
feature_columns = []
metrics_summary = {}
df_telemetry = None
df_machines = None
df_features = None
active_alerts = []
work_orders = []

def load_artifacts():
    global model, feature_columns, metrics_summary, df_telemetry, df_machines, df_features, active_alerts
    
    if os.path.exists(MODEL_PATH):
        model = joblib.load(MODEL_PATH)
        print(f"[Server] Loaded model from {MODEL_PATH}")
        
    if os.path.exists(FEATURES_PATH):
        with open(FEATURES_PATH, "r") as f:
            feature_columns = json.load(f)
            
    if os.path.exists(METRICS_PATH):
        with open(METRICS_PATH, "r") as f:
            metrics_summary = json.load(f)
            
    mach_path = os.path.join(DATA_RAW_DIR, "machine_metadata.csv")
    if os.path.exists(mach_path):
        df_machines = pd.read_csv(mach_path)
        
    telem_path = os.path.join(DATA_RAW_DIR, "sensor_telemetry.csv")
    if os.path.exists(telem_path):
        df_telemetry = pd.read_csv(telem_path)
        df_telemetry['timestamp'] = pd.to_datetime(df_telemetry['timestamp'])
        
    feat_path = os.path.join(DATA_PROCESSED_DIR, "features_engineered.csv")
    if os.path.exists(feat_path):
        df_features = pd.read_csv(feat_path)
        df_features['timestamp'] = pd.to_datetime(df_features['timestamp'])
        
    # Generate initial active alerts based on latest state
    refresh_alerts()

def refresh_alerts():
    global active_alerts
    active_alerts = []
    if df_features is None or model is None:
        return
        
    # Get latest row per machine
    latest_rows = df_features.sort_values(by='timestamp').groupby('machine_id').last().reset_index()
    X_latest = latest_rows[feature_columns].values
    probas = model.predict_proba(X_latest)[:, 1]
    
    for idx, row in latest_rows.iterrows():
        p = float(probas[idx])
        m_id = row['machine_id']
        
        status = "HEALTHY"
        severity = "INFO"
        if p >= 0.60:
            status = "CRITICAL"
            severity = "CRITICAL"
        elif p >= 0.30:
            status = "WARNING"
            severity = "WARNING"
            
        if status in ["WARNING", "CRITICAL"]:
            # Check primary contributing driver
            reason = "Elevated mechanical stress"
            if row.get('vibration_roll_mean_12h', 0) > 4.5:
                reason = "Severe bearing wear & vibration flutter detected"
            elif row.get('temp_above_ambient', 0) > 55:
                reason = "Thermal runaway danger - abnormal heat dissipation"
            elif row.get('pressure_deviation_24h', 0) < -20:
                reason = "Hydraulic pressure seal leakage risk"
            elif row.get('hours_since_last_service', 0) > 500:
                reason = "Overdue preventive service schedule exceeded"
                
            active_alerts.append({
                "alert_id": f"ALT-{m_id}-{int(datetime.now().timestamp()) % 10000}",
                "machine_id": m_id,
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "risk_score": round(p * 100, 1),
                "severity": severity,
                "reason": reason,
                "recommended_action": "Emergency Inspection & Bearing Replacement" if severity == "CRITICAL" else "Schedule Preventive Lubrication & Sensor Calibration"
            })

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/fleet", methods=["GET"])
def get_fleet_status():
    """
    Returns real-time status, health index, risk scores, and telemetry for all machines.
    """
    if df_features is None or model is None:
        load_artifacts()
        
    if df_features is None or model is None:
        return jsonify({"error": "Pipeline has not completed training yet"}), 503
        
    latest_rows = df_features.sort_values(by='timestamp').groupby('machine_id').last().reset_index()
    X_latest = latest_rows[feature_columns].values
    probas = model.predict_proba(X_latest)[:, 1]
    
    fleet = []
    healthy_count = 0
    warning_count = 0
    critical_count = 0
    
    for idx, row in latest_rows.iterrows():
        p = float(probas[idx])
        risk_pct = round(p * 100.0, 1)
        m_id = row['machine_id']
        
        # Machine metadata lookup
        mach_meta = {}
        if df_machines is not None:
            match = df_machines[df_machines['machine_id'] == m_id]
            if not match.empty:
                mach_meta = match.iloc[0].to_dict()
                
        if risk_pct >= 60.0:
            status = "CRITICAL"
            critical_count += 1
            est_hours = max(2, int((100.0 - risk_pct) * 0.4))
        elif risk_pct >= 30.0:
            status = "WARNING"
            warning_count += 1
            est_hours = max(12, int((100.0 - risk_pct) * 0.8))
        else:
            status = "HEALTHY"
            healthy_count += 1
            est_hours = None
            
        fleet.append({
            "machine_id": m_id,
            "machine_type": mach_meta.get("machine_type", "Industrial Unit"),
            "model": mach_meta.get("model", "Pro-Series"),
            "location_zone": mach_meta.get("location_zone", "Zone-A"),
            "status": status,
            "failure_risk_pct": risk_pct,
            "est_hours_to_failure": est_hours,
            "temperature": round(float(row.get('temperature', 0)), 1),
            "vibration": round(float(row.get('vibration', 0)), 2),
            "pressure": round(float(row.get('pressure', 0)), 1),
            "operating_hours": int(row.get('operating_hours', 0)),
            "hours_since_last_service": int(row.get('hours_since_last_service', 0)),
            "lubrication_level": round(float(row.get('lubrication_level', 90)), 1),
            "last_updated": row['timestamp'].strftime("%Y-%m-%d %H:%M")
        })
        
    avg_fleet_risk = round(float(np.mean(probas) * 100.0), 1)
    fleet_health_score = round(100.0 - avg_fleet_risk, 1)
    
    return jsonify({
        "summary": {
            "total_machines": len(fleet),
            "healthy": healthy_count,
            "warning": warning_count,
            "critical": critical_count,
            "fleet_health_score": fleet_health_score,
            "active_alerts_count": len(active_alerts)
        },
        "machines": fleet
    })

@app.route("/api/telemetry/<machine_id>", methods=["GET"])
def get_machine_telemetry(machine_id):
    """
    Returns recent time series history (last 72 hours) for a machine.
    """
    if df_telemetry is None:
        load_artifacts()
        
    m_data = df_telemetry[df_telemetry['machine_id'] == machine_id].sort_values(by='timestamp').tail(72)
    if m_data.empty:
        return jsonify({"error": f"Machine {machine_id} not found"}), 404
        
    timestamps = [ts.strftime("%m-%d %H:%M") for ts in m_data['timestamp']]
    temps = m_data['temperature'].tolist()
    vibs = m_data['vibration'].tolist()
    pressures = m_data['pressure'].tolist()
    loads = m_data['operational_load'].tolist()
    
    # Metadata
    meta = {}
    if df_machines is not None:
        m_row = df_machines[df_machines['machine_id'] == machine_id]
        if not m_row.empty:
            meta = m_row.iloc[0].to_dict()
            
    # Baseline normal limits
    thresholds = {
        "temp_warning": 80.0,
        "temp_critical": 92.0,
        "vib_warning": 4.5,
        "vib_critical": 6.8,
        "press_min_warning": 75.0,
        "press_max_warning": 170.0
    }
    
    return jsonify({
        "machine_id": machine_id,
        "metadata": meta,
        "timestamps": timestamps,
        "temperature": temps,
        "vibration": vibs,
        "pressure": pressures,
        "operational_load": loads,
        "thresholds": thresholds
    })

@app.route("/api/predict", methods=["POST"])
def predict_what_if():
    """
    Interactive What-If Simulation Endpoint.
    Accepts arbitrary sensor inputs and runs model inference to simulate future failure risk.
    """
    if model is None or len(feature_columns) == 0:
        load_artifacts()
        
    data = request.json or {}
    
    temp = float(data.get("temperature", 70.0))
    vib = float(data.get("vibration", 2.5))
    pressure = float(data.get("pressure", 100.0))
    load = float(data.get("operational_load", 0.8))
    ambient = float(data.get("ambient_temp", 24.0))
    service_hrs = float(data.get("hours_since_last_service", 120.0))
    lubrication = float(data.get("lubrication_level", 85.0))
    
    # Synthesize feature dictionary aligned with feature_columns
    feat_dict = {}
    vib_excess = max(0.0, vib - 2.2)
    temp_excess = max(0.0, temp - 65.0)

    for col in feature_columns:
        if col == "temperature":
            feat_dict[col] = temp
        elif col == "vibration":
            feat_dict[col] = vib
        elif col == "pressure":
            feat_dict[col] = pressure
        elif col == "operational_load":
            feat_dict[col] = load
        elif col == "ambient_temp":
            feat_dict[col] = ambient
        elif col == "lubrication_level":
            feat_dict[col] = lubrication
        elif col == "hours_since_last_service":
            feat_dict[col] = service_hrs
        elif "roll_mean" in col:
            if "temperature" in col:
                feat_dict[col] = temp - temp_excess * (0.1 if "3h" in col else 0.25)
            elif "vibration" in col:
                feat_dict[col] = vib - vib_excess * (0.08 if "3h" in col else 0.22)
            else:
                feat_dict[col] = pressure
        elif "roll_std" in col:
            if "vibration" in col:
                feat_dict[col] = 0.18 + vib_excess * (0.35 if "3h" in col else 0.45)
            elif "temperature" in col:
                feat_dict[col] = 0.6 + temp_excess * 0.15
            else:
                feat_dict[col] = 1.2
        elif "roll_max" in col:
            base = temp if "temperature" in col else (vib if "vibration" in col else pressure)
            feat_dict[col] = base * 1.05
        elif "roll_min" in col:
            base = temp if "temperature" in col else (vib if "vibration" in col else pressure)
            feat_dict[col] = base * 0.90
        elif "roll_range" in col:
            if "vibration" in col:
                feat_dict[col] = max(0.4, vib_excess * 0.85)
            elif "temperature" in col:
                feat_dict[col] = max(1.5, temp_excess * 0.5)
            else:
                feat_dict[col] = 4.0
        elif "lag_1h" in col:
            if "vibration" in col:
                feat_dict[col] = vib - vib_excess * 0.08
            elif "temperature" in col:
                feat_dict[col] = temp - temp_excess * 0.08
            else:
                feat_dict[col] = pressure
        elif "lag_3h" in col:
            if "vibration" in col:
                feat_dict[col] = vib - vib_excess * 0.22
            elif "temperature" in col:
                feat_dict[col] = temp - temp_excess * 0.22
            else:
                feat_dict[col] = pressure
        elif "diff_1h" in col:
            feat_dict[col] = temp_excess * 0.08 if "temperature" in col else (vib_excess * 0.08 if "vibration" in col else -1.5)
        elif "diff_3h" in col:
            feat_dict[col] = temp_excess * 0.22 if "temperature" in col else (vib_excess * 0.22 if "vibration" in col else -3.5)
        elif "accel_3h" in col:
            feat_dict[col] = 0.3 if vib > 4.5 else 0.05
        elif col == "vib_to_load_ratio":
            feat_dict[col] = vib / max(0.05, load)
        elif col == "temp_above_ambient":
            feat_dict[col] = temp - ambient
        elif col == "pressure_deviation_24h":
            feat_dict[col] = pressure - 100.0
        elif col == "service_stress_index":
            feat_dict[col] = np.log1p(service_hrs) * vib
        elif col == "lubrication_risk":
            feat_dict[col] = 100.0 - lubrication
        else:
            feat_dict[col] = 0.0
            
    # Create input vector
    X_input = np.array([[feat_dict.get(c, 0.0) for c in feature_columns]])
    proba = float(model.predict_proba(X_input)[0, 1])
    risk_pct = round(proba * 100.0, 1)
    
    if risk_pct >= 60.0:
        status = "CRITICAL"
        action = "Immediate Shutdown & Bearing Replacement Recommended"
        urgency = "Within 4 to 8 hours"
    elif risk_pct >= 30.0:
        status = "WARNING"
        action = "Schedule Maintenance Inspection & Relubrication"
        urgency = "Within 24 hours"
    else:
        status = "HEALTHY"
        action = "Normal Operations - Continue Standard Sensor Monitoring"
        urgency = "Routine (Next scheduled cycle)"
        
    # Top driving factors
    drivers = []
    if vib > 4.5:
        drivers.append(f"Excessive Vibration ({vib:.2f} mm/s RMS) exceeds ISO 10816 threshold")
    if temp > 80:
        drivers.append(f"Thermal Elevation ({temp:.1f}°C) indicates internal mechanical friction")
    if service_hrs > 450:
        drivers.append(f"Service Wear: {int(service_hrs)} operating hours since last maintenance overhaul")
    if lubrication < 40:
        drivers.append(f"Depleted Lubricant ({lubrication:.1f}%) accelerates metal-to-metal spalling")
    if not drivers:
        drivers.append("All mechanical & thermal telemetry within normal baseline envelope")

    return jsonify({
        "failure_risk_pct": risk_pct,
        "prediction_window_hours": 24,
        "status": status,
        "recommended_action": action,
        "intervention_urgency": urgency,
        "key_risk_drivers": drivers
    })

@app.route("/api/metrics", methods=["GET"])
def get_metrics():
    """
    Returns model evaluation metrics, PR curves, Confusion Matrix, and Financial ROI.
    """
    if not metrics_summary:
        load_artifacts()
    return jsonify(metrics_summary)

@app.route("/api/alerts", methods=["GET"])
def get_alerts():
    refresh_alerts()
    return jsonify({
        "alerts": active_alerts,
        "work_orders": work_orders
    })

@app.route("/api/alerts/dispatch", methods=["POST"])
def dispatch_work_order():
    """
    Creates and logs a maintenance work order, acknowledging an alert.
    """
    data = request.json or {}
    machine_id = data.get("machine_id", "M-101")
    technician = data.get("technician", "Field Engineering Team A")
    priority = data.get("priority", "HIGH")
    
    order = {
        "order_id": f"WO-{int(datetime.now().timestamp()) % 100000}",
        "machine_id": machine_id,
        "technician": technician,
        "priority": priority,
        "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "status": "DISPATCHED",
        "scope": f"Preventive bearing inspection and seal overhaul for {machine_id}"
    }
    work_orders.insert(0, order)
    
    # Remove related alert
    global active_alerts
    active_alerts = [a for a in active_alerts if a["machine_id"] != machine_id]
    
    return jsonify({
        "message": f"Work order {order['order_id']} dispatched for {machine_id}",
        "work_order": order
    })

@app.route("/api/inject_anomaly", methods=["POST"])
def inject_anomaly():
    """
    Allows user to trigger an artificial bearing failure or thermal runaway
    on a selected machine to watch alerts light up in real time!
    """
    data = request.json or {}
    machine_id = data.get("machine_id", "M-102")
    anomaly_type = data.get("anomaly_type", "BEARING_DEGRADATION")
    
    global df_telemetry, df_features
    if df_telemetry is not None and df_features is not None:
        # Boost latest readings for this machine
        last_t_idx = df_telemetry[df_telemetry['machine_id'] == machine_id].index[-1]
        last_f_idx = df_features[df_features['machine_id'] == machine_id].index[-1]
        
        if anomaly_type == "BEARING_DEGRADATION":
            df_telemetry.loc[last_t_idx, 'vibration'] = 7.8
            df_telemetry.loc[last_t_idx, 'temperature'] = 86.5
            df_features.loc[last_f_idx, 'vibration'] = 7.8
            df_features.loc[last_f_idx, 'vibration_roll_mean_12h'] = 6.9
            df_features.loc[last_f_idx, 'vibration_roll_max_24h'] = 8.1
            df_features.loc[last_f_idx, 'temperature'] = 86.5
            df_features.loc[last_f_idx, 'temp_above_ambient'] = 62.0
        elif anomaly_type == "THERMAL_RUNAWAY":
            df_telemetry.loc[last_t_idx, 'temperature'] = 98.4
            df_features.loc[last_f_idx, 'temperature'] = 98.4
            df_features.loc[last_f_idx, 'temp_above_ambient'] = 74.0
            df_features.loc[last_f_idx, 'temperature_roll_mean_12h'] = 94.2
        elif anomaly_type == "PRESSURE_SEAL_FAILURE":
            df_telemetry.loc[last_t_idx, 'pressure'] = 45.0
            df_features.loc[last_f_idx, 'pressure'] = 45.0
            df_features.loc[last_f_idx, 'pressure_deviation_24h'] = -65.0
            
    refresh_alerts()
    return jsonify({
        "status": "success",
        "message": f"Injected {anomaly_type} anomaly into {machine_id}. Real-time risk elevated."
    })

@app.route("/api/reset_machine", methods=["POST"])
def reset_machine():
    """
    Simulates completion of maintenance on a machine, returning it to healthy state.
    """
    data = request.json or {}
    machine_id = data.get("machine_id", "M-101")
    
    global df_telemetry, df_features
    if df_telemetry is not None and df_features is not None:
        last_t_idx = df_telemetry[df_telemetry['machine_id'] == machine_id].index[-1]
        last_f_idx = df_features[df_features['machine_id'] == machine_id].index[-1]
        
        df_telemetry.loc[last_t_idx, 'vibration'] = 2.1
        df_telemetry.loc[last_t_idx, 'temperature'] = 64.0
        df_telemetry.loc[last_t_idx, 'pressure'] = 110.0
        df_telemetry.loc[last_t_idx, 'lubrication_level'] = 98.0
        df_telemetry.loc[last_t_idx, 'hours_since_last_service'] = 0
        
        df_features.loc[last_f_idx, 'vibration'] = 2.1
        df_features.loc[last_f_idx, 'vibration_roll_mean_12h'] = 2.2
        df_features.loc[last_f_idx, 'temperature'] = 64.0
        df_features.loc[last_f_idx, 'temp_above_ambient'] = 40.0
        df_features.loc[last_f_idx, 'pressure'] = 110.0
        df_features.loc[last_f_idx, 'pressure_deviation_24h'] = 0.0
        df_features.loc[last_f_idx, 'lubrication_level'] = 98.0
        df_features.loc[last_f_idx, 'lubrication_risk'] = 2.0
        df_features.loc[last_f_idx, 'hours_since_last_service'] = 0
        
    refresh_alerts()
    return jsonify({
        "status": "success",
        "message": f"Machine {machine_id} overhauled. Sensors restored to factory baseline."
    })

if __name__ == "__main__":
    load_artifacts()
    app.run(host="0.0.0.0", port=5000, debug=True)
