/**
 * Sentinel-AI Predictive Maintenance Frontend Application
 * Handles SCADA telemetry rendering, Chart.js graphs, What-If simulation,
 * active alerts, and work order dispatching.
 */

let currentFleet = [];
let selectedMachineId = "M-101";
let telemetryChartInstance = null;
let prChartInstance = null;
let featImportanceChartInstance = null;
let currentMetricView = "vibration"; // 'vibration', 'temperature', 'pressure'
let cachedTelemetryData = null;

// Initialize Application
document.addEventListener("DOMContentLoaded", () => {
  setupTabs();
  setupEventListeners();
  loadFleetData();
  loadMetricsData();
  setupSimulatorControls();
  
  // Auto-refresh fleet telemetry every 30 seconds
  setInterval(loadFleetData, 30000);
});

// Tab Navigation
function setupTabs() {
  const tabs = document.querySelectorAll(".tab-btn");
  tabs.forEach(btn => {
    btn.addEventListener("click", () => {
      tabs.forEach(t => t.classList.remove("active"));
      document.querySelectorAll(".tab-content").forEach(c => c.classList.remove("active"));
      
      btn.classList.add("active");
      const targetId = btn.getAttribute("data-tab");
      const content = document.getElementById(targetId);
      if (content) content.classList.add("active");

      // Resize or render charts if tab changed
      if (targetId === "tab-telemetry" && selectedMachineId) {
        loadMachineTelemetry(selectedMachineId);
      }
    });
  });
}

// Global Event Listeners
function setupEventListeners() {
  document.getElementById("btn-refresh-fleet").addEventListener("click", () => {
    loadFleetData();
    showToast("Syncing fleet telemetry across all nodes...", "info");
  });

  document.getElementById("machine-select-dropdown").addEventListener("change", (e) => {
    selectedMachineId = e.target.value;
    loadMachineTelemetry(selectedMachineId);
  });

  // Chart view switch buttons
  document.getElementById("btn-chart-vib").addEventListener("click", () => switchChartMetric("vibration"));
  document.getElementById("btn-chart-temp").addEventListener("click", () => switchChartMetric("temperature"));
  document.getElementById("btn-chart-press").addEventListener("click", () => switchChartMetric("pressure"));

  // Work order dispatch modal
  document.getElementById("btn-dispatch-order-action").addEventListener("click", () => {
    openWorkOrderModal(selectedMachineId);
  });
  document.getElementById("btn-close-wo-modal").addEventListener("click", closeWorkOrderModal);
  document.getElementById("btn-cancel-wo").addEventListener("click", closeWorkOrderModal);
  document.getElementById("form-work-order").addEventListener("submit", handleWorkOrderSubmit);

  // Overhaul reset button
  document.getElementById("btn-reset-machine-action").addEventListener("click", () => {
    resetMachineToBaseline(selectedMachineId);
  });

  // Anomaly Injection Modal
  document.getElementById("btn-open-simulate-modal").addEventListener("click", openInjectModal);
  document.getElementById("btn-close-inject-modal").addEventListener("click", closeInjectModal);
  document.getElementById("btn-cancel-inject").addEventListener("click", closeInjectModal);
  document.getElementById("form-inject-anomaly").addEventListener("submit", handleInjectAnomalySubmit);
}

// Fetch and Render Fleet
async function loadFleetData() {
  try {
    const res = await fetch("/api/fleet");
    if (!res.ok) throw new Error("Failed to load fleet data");
    const data = await res.json();
    currentFleet = data.machines;

    // Update KPI summary cards
    document.getElementById("kpi-total-machines").textContent = data.summary.total_machines;
    document.getElementById("kpi-critical-count").textContent = data.summary.critical;
    document.getElementById("kpi-fleet-health").textContent = `${data.summary.fleet_health_score}%`;
    document.getElementById("kpi-machines-status").textContent = 
      `${data.summary.healthy} Healthy • ${data.summary.warning} Warning • ${data.summary.critical} Critical`;

    // Update Tab Badge
    const alertCount = data.summary.active_alerts_count;
    const badge = document.getElementById("alert-tab-badge");
    badge.textContent = alertCount;
    badge.style.display = alertCount > 0 ? "inline-block" : "none";

    renderFleetGrid(currentFleet);
    populateMachineDropdowns(currentFleet);
    loadAlertsData();

  } catch (err) {
    console.error("Error loading fleet data:", err);
  }
}

// Render Fleet Grid
function renderFleetGrid(machines) {
  const container = document.getElementById("fleet-card-container");
  container.innerHTML = "";

  machines.forEach(m => {
    const card = document.createElement("div");
    const statusClass = m.status.toLowerCase();
    card.className = `machine-card ${statusClass} ${m.machine_id === selectedMachineId ? 'selected' : ''}`;
    
    // Progress bar color
    let barColor = "var(--success)";
    if (m.status === "WARNING") barColor = "var(--warning)";
    if (m.status === "CRITICAL") barColor = "var(--danger)";

    card.innerHTML = `
      <div class="mach-card-header">
        <div>
          <div class="mach-id">${m.machine_id}</div>
          <div class="mach-type">${m.machine_type} • ${m.model}</div>
        </div>
        <span class="status-badge ${statusClass}">${m.status}</span>
      </div>

      <div class="risk-meter-container">
        <div class="risk-label-row">
          <span>Failure Risk (24h)</span>
          <span style="font-weight: 700; color: ${barColor}">${m.failure_risk_pct}%</span>
        </div>
        <div class="risk-progress-bg">
          <div class="risk-progress-bar" style="width: ${m.failure_risk_pct}%; background: ${barColor};"></div>
        </div>
      </div>

      <div class="telemetry-mini-grid">
        <div class="mini-telemetry-item">
          <div class="mini-label">Vib RMS</div>
          <div class="mini-value">${m.vibration} <span style="font-size:0.65rem">mm/s</span></div>
        </div>
        <div class="mini-telemetry-item">
          <div class="mini-label">Temp</div>
          <div class="mini-value">${m.temperature}°C</div>
        </div>
        <div class="mini-telemetry-item">
          <div class="mini-label">Pressure</div>
          <div class="mini-value">${m.pressure} <span style="font-size:0.65rem">PSI</span></div>
        </div>
      </div>

      <div class="mach-card-footer">
        <span>${m.location_zone}</span>
        <span>Service: ${m.hours_since_last_service}h ago</span>
        ${m.est_hours_to_failure ? `<span style="color:var(--danger); font-weight:700">~${m.est_hours_to_failure}h to fail</span>` : '<span>Nominal</span>'}
      </div>
    `;

    card.addEventListener("click", () => {
      selectedMachineId = m.machine_id;
      document.querySelectorAll(".machine-card").forEach(c => c.classList.remove("selected"));
      card.classList.add("selected");
      
      // Switch to Telemetry tab
      document.querySelector('[data-tab="tab-telemetry"]').click();
      document.getElementById("machine-select-dropdown").value = m.machine_id;
      loadMachineTelemetry(m.machine_id);
    });

    container.appendChild(card);
  });
}

function populateMachineDropdowns(machines) {
  const select = document.getElementById("machine-select-dropdown");
  const injectSelect = document.getElementById("inject-target-machine");
  
  const currentVal = select.value || selectedMachineId;
  select.innerHTML = "";
  injectSelect.innerHTML = "";

  machines.forEach(m => {
    const opt = document.createElement("option");
    opt.value = m.machine_id;
    opt.textContent = `${m.machine_id} - ${m.machine_type} (${m.status})`;
    select.appendChild(opt);

    const opt2 = document.createElement("option");
    opt2.value = m.machine_id;
    opt2.textContent = `${m.machine_id} (${m.machine_type})`;
    injectSelect.appendChild(opt2);
  });

  select.value = currentVal;
}

// Telemetry Details & Charting
async function loadMachineTelemetry(machineId) {
  try {
    const res = await fetch(`/api/telemetry/${machineId}`);
    if (!res.ok) throw new Error("Failed to load telemetry");
    const data = await res.json();
    cachedTelemetryData = data;

    // Update Sidebar
    const machMeta = currentFleet.find(m => m.machine_id === machineId) || {};
    document.getElementById("current-chart-machine-label").textContent = 
      `${machineId} Telemetry & Degradation Envelope (72h Horizon)`;
    
    document.getElementById("diag-machine-id").textContent = machineId;
    const badge = document.getElementById("diag-status-badge");
    const status = machMeta.status || "HEALTHY";
    badge.className = `status-badge ${status.toLowerCase()}`;
    badge.textContent = status;

    document.getElementById("diag-model").textContent = machMeta.model || data.metadata.model || "--";
    document.getElementById("diag-zone").textContent = machMeta.location_zone || data.metadata.location_zone || "--";
    document.getElementById("diag-hours").textContent = `${machMeta.operating_hours || "--"} hrs`;
    document.getElementById("diag-service-hrs").textContent = `${machMeta.hours_since_last_service || "--"} hrs`;
    document.getElementById("diag-risk-pct").textContent = `${machMeta.failure_risk_pct || 0}%`;
    document.getElementById("diag-time-to-fail").textContent = 
      machMeta.est_hours_to_failure ? `Est. ${machMeta.est_hours_to_failure} hrs remaining` : "No breakdown imminent";

    // Advisory recommendation
    const adv = document.getElementById("diag-advisory-text");
    if (status === "CRITICAL") {
      adv.textContent = `CRITICAL WARNING: AI model predicts machine failure breakdown within 24 hours. Immediate mechanical inspection and bearing race replacement required to avert catastrophic downtime.`;
      adv.style.color = "var(--danger)";
    } else if (status === "WARNING") {
      adv.textContent = `ELEVATED WEAR: Vibration or thermal dissipation is diverging from nominal envelope. Recommend dispatching technician for preventive filter clean and lubrication pack.`;
      adv.style.color = "var(--warning)";
    } else {
      adv.textContent = `Condition baseline normal. Continuous vibration spectrum and thermal readings well below ISO threshold limits.`;
      adv.style.color = "var(--text-secondary)";
    }

    renderTelemetryChart(data, currentMetricView);

  } catch (err) {
    console.error("Telemetry load error:", err);
  }
}

function switchChartMetric(metric) {
  currentMetricView = metric;
  document.getElementById("btn-chart-vib").classList.toggle("active", metric === "vibration");
  document.getElementById("btn-chart-temp").classList.toggle("active", metric === "temperature");
  document.getElementById("btn-chart-press").classList.toggle("active", metric === "pressure");

  if (cachedTelemetryData) {
    renderTelemetryChart(cachedTelemetryData, metric);
  }
}

function renderTelemetryChart(data, metric) {
  const canvas = document.getElementById("telemetryChart");
  if (!canvas) return;

  const labels = data.timestamps;
  let seriesData = [];
  let seriesLabel = "";
  let lineColor = "#06b6d4";
  let warnThreshold = null;
  let critThreshold = null;

  if (metric === "vibration") {
    seriesData = data.vibration;
    seriesLabel = "Vibration Velocity (mm/s RMS)";
    lineColor = "#06b6d4";
    warnThreshold = data.thresholds.vib_warning;
    critThreshold = data.thresholds.vib_critical;
  } else if (metric === "temperature") {
    seriesData = data.temperature;
    seriesLabel = "Component Temperature (°C)";
    lineColor = "#f59e0b";
    warnThreshold = data.thresholds.temp_warning;
    critThreshold = data.thresholds.temp_critical;
  } else if (metric === "pressure") {
    seriesData = data.pressure;
    seriesLabel = "Hydraulic Pressure (PSI)";
    lineColor = "#8b5cf6";
    warnThreshold = data.thresholds.press_min_warning;
  }

  // Check if Chart.js is loaded
  if (typeof Chart !== "undefined") {
    if (telemetryChartInstance) {
      telemetryChartInstance.destroy();
    }

    const datasets = [
      {
        label: seriesLabel,
        data: seriesData,
        borderColor: lineColor,
        backgroundColor: lineColor + "22",
        borderWidth: 2,
        tension: 0.3,
        fill: true,
        pointRadius: 2,
        pointHoverRadius: 5
      }
    ];

    if (warnThreshold !== null) {
      datasets.push({
        label: `Warning Threshold (${warnThreshold})`,
        data: Array(labels.length).fill(warnThreshold),
        borderColor: "#f59e0b",
        borderDash: [5, 5],
        borderWidth: 1.5,
        fill: false,
        pointRadius: 0
      });
    }

    if (critThreshold !== null) {
      datasets.push({
        label: `Critical Alarm Threshold (${critThreshold})`,
        data: Array(labels.length).fill(critThreshold),
        borderColor: "#ef4444",
        borderDash: [3, 3],
        borderWidth: 2,
        fill: false,
        pointRadius: 0
      });
    }

    telemetryChartInstance = new Chart(canvas, {
      type: "line",
      data: {
        labels: labels,
        datasets: datasets
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: {
          mode: 'index',
          intersect: false
        },
        plugins: {
          legend: {
            labels: { color: "#94a3b8", font: { family: 'Outfit', size: 11 } }
          },
          tooltip: {
            backgroundColor: "#111827",
            titleColor: "#f8fafc",
            borderColor: "rgba(255,255,255,0.1)",
            borderWidth: 1
          }
        },
        scales: {
          x: {
            grid: { color: "rgba(255, 255, 255, 0.05)" },
            ticks: { color: "#64748b", font: { size: 10 }, maxTicksLimit: 12 }
          },
          y: {
            grid: { color: "rgba(255, 255, 255, 0.05)" },
            ticks: { color: "#64748b", font: { size: 10 } }
          }
        }
      }
    });
  } else {
    // Pure Canvas fallback if Chart.js is not loaded
    drawCanvasFallbackLineChart(canvas, labels, seriesData, lineColor);
  }
}

// Fallback Canvas Renderer for Offline Environments
function drawCanvasFallbackLineChart(canvas, labels, data, color) {
  const ctx = canvas.getContext("2d");
  const w = canvas.width = canvas.parentElement.clientWidth;
  const h = canvas.height = canvas.parentElement.clientHeight;

  ctx.clearRect(0, 0, w, h);
  if (!data || data.length === 0) return;

  const min = Math.min(...data) * 0.9;
  const max = Math.max(...data) * 1.1;
  const range = max - min || 1;

  ctx.strokeStyle = color;
  ctx.lineWidth = 2;
  ctx.beginPath();

  data.forEach((val, i) => {
    const x = (i / (data.length - 1)) * (w - 40) + 20;
    const y = h - ((val - min) / range) * (h - 40) - 20;
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  });
  ctx.stroke();

  ctx.fillStyle = "#94a3b8";
  ctx.font = "11px Outfit";
  ctx.fillText(`Min: ${min.toFixed(1)} | Max: ${max.toFixed(1)}`, 20, 20);
}

// Interactive What-If Simulator Controls
function setupSimulatorControls() {
  const simVib = document.getElementById("sim-vib");
  const simTemp = document.getElementById("sim-temp");
  const simPress = document.getElementById("sim-press");
  const simHours = document.getElementById("sim-hours");
  const simLub = document.getElementById("sim-lub");

  const inputs = [simVib, simTemp, simPress, simHours, simLub];
  let debounceTimeout = null;

  const triggerSim = () => {
    document.getElementById("val-sim-vib").textContent = `${simVib.value} mm/s`;
    document.getElementById("val-sim-temp").textContent = `${simTemp.value} °C`;
    document.getElementById("val-sim-press").textContent = `${simPress.value} PSI`;
    document.getElementById("val-sim-hours").textContent = `${simHours.value} hrs`;
    document.getElementById("val-sim-lub").textContent = `${simLub.value} %`;

    clearTimeout(debounceTimeout);
    debounceTimeout = setTimeout(runWhatIfInference, 200);
  };

  inputs.forEach(inp => inp.addEventListener("input", triggerSim));

  // Presets
  document.getElementById("btn-preset-nominal").addEventListener("click", () => {
    simVib.value = 2.1;
    simTemp.value = 65.0;
    simPress.value = 115.0;
    simHours.value = 100;
    simLub.value = 95;
    triggerSim();
  });

  document.getElementById("btn-preset-bearing-wear").addEventListener("click", () => {
    simVib.value = 6.8;
    simTemp.value = 84.5;
    simPress.value = 108.0;
    simHours.value = 520;
    simLub.value = 35;
    triggerSim();
  });

  document.getElementById("btn-preset-overheating").addEventListener("click", () => {
    simVib.value = 4.2;
    simTemp.value = 96.0;
    simPress.value = 90.0;
    simHours.value = 480;
    simLub.value = 25;
    triggerSim();
  });

  // Run initial simulation
  runWhatIfInference();
}

async function runWhatIfInference() {
  const payload = {
    vibration: parseFloat(document.getElementById("sim-vib").value),
    temperature: parseFloat(document.getElementById("sim-temp").value),
    pressure: parseFloat(document.getElementById("sim-press").value),
    hours_since_last_service: parseFloat(document.getElementById("sim-hours").value),
    lubrication_level: parseFloat(document.getElementById("sim-lub").value),
    operational_load: 0.85,
    ambient_temp: 24.0
  };

  try {
    const res = await fetch("/api/predict", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    if (!res.ok) throw new Error("Simulation failed");
    const result = await res.json();

    const score = result.failure_risk_pct;
    document.getElementById("sim-result-score").textContent = `${score}%`;
    const tier = document.getElementById("sim-result-tier");
    tier.textContent = result.status;

    let circleColor = "var(--success)";
    if (result.status === "WARNING") circleColor = "var(--warning)";
    if (result.status === "CRITICAL") circleColor = "var(--danger)";
    tier.style.color = circleColor;

    // Update circular gauge background
    const circle = document.getElementById("sim-gauge-circle");
    circle.style.background = `conic-gradient(${circleColor} 0% ${score}%, rgba(255,255,255,0.06) ${score}% 100%)`;

    // Prescriptions
    document.getElementById("sim-action-title").textContent = `Prescription (${result.intervention_urgency}):`;
    document.getElementById("sim-action-text").textContent = result.recommended_action;

    // Driving factors list
    const driversList = document.getElementById("sim-drivers-list");
    driversList.innerHTML = "";
    (result.key_risk_drivers || []).forEach(d => {
      const li = document.createElement("li");
      li.textContent = d;
      driversList.appendChild(li);
    });

  } catch (err) {
    console.error("Simulation error:", err);
  }
}

// Model Benchmark & ROI Data
async function loadMetricsData() {
  try {
    const res = await fetch("/api/metrics");
    if (!res.ok) return;
    const data = await res.json();
    const champ = data.champion_model_name;
    const modelStats = data.models_benchmarks[champ].default_threshold_metrics;

    // KPI values
    document.getElementById("metric-pr-auc").textContent = modelStats.pr_auc.toFixed(4);
    document.getElementById("metric-recall").textContent = `${(modelStats.recall * 100).toFixed(1)}%`;
    document.getElementById("metric-precision").textContent = `${(modelStats.precision * 100).toFixed(1)}%`;
    document.getElementById("metric-false-alarms").textContent = `${(modelStats.false_alarm_rate * 100).toFixed(2)}%`;

    // Confusion Matrix
    const cm = modelStats.confusion_matrix;
    document.getElementById("cm-tn").textContent = cm.true_negatives.toLocaleString();
    document.getElementById("cm-fp").textContent = cm.false_positives_false_alarms.toLocaleString();
    document.getElementById("cm-fn").textContent = cm.false_negatives_missed.toLocaleString();
    document.getElementById("cm-tp").textContent = cm.true_positives_detected.toLocaleString();

    // Cost Model
    const cost = modelStats.cost_analysis;
    document.getElementById("cost-baseline-val").textContent = `$${cost.baseline_run_to_failure_cost_usd.toLocaleString()}`;
    document.getElementById("cost-model-val").textContent = `$${cost.model_operational_cost_usd.toLocaleString()}`;
    document.getElementById("cost-net-savings").textContent = 
      `+$${cost.net_savings_usd.toLocaleString()} (${cost.roi_percent}% ROI)`;
    document.getElementById("kpi-cost-savings").textContent = `$${cost.net_savings_usd.toLocaleString()}`;

    // Render Charts
    renderPRCurve(modelStats.pr_curve_sample);
    renderFeatureImportanceChart(data.top_feature_importances);

  } catch (err) {
    console.error("Metrics load error:", err);
  }
}

function renderPRCurve(prSample) {
  const canvas = document.getElementById("prCurveChart");
  if (!canvas || typeof Chart === "undefined" || !prSample) return;

  if (prChartInstance) prChartInstance.destroy();

  const points = prSample.recall.map((r, i) => ({ x: r, y: prSample.precision[i] }));

  prChartInstance = new Chart(canvas, {
    type: "line",
    data: {
      datasets: [{
        label: "Precision-Recall Curve",
        data: points,
        borderColor: "#06b6d4",
        backgroundColor: "rgba(6, 182, 212, 0.15)",
        fill: true,
        tension: 0.2,
        pointRadius: 2
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        x: {
          type: "linear",
          title: { display: true, text: "Recall (Failure Detection Rate)", color: "#94a3b8" },
          min: 0,
          max: 1.0,
          grid: { color: "rgba(255,255,255,0.05)" },
          ticks: { color: "#64748b" }
        },
        y: {
          title: { display: true, text: "Precision (Alarm Purity)", color: "#94a3b8" },
          min: 0,
          max: 1.05,
          grid: { color: "rgba(255,255,255,0.05)" },
          ticks: { color: "#64748b" }
        }
      },
      plugins: {
        legend: { display: false }
      }
    }
  });
}

function renderFeatureImportanceChart(topFeatures) {
  const canvas = document.getElementById("featureImportanceChart");
  if (!canvas || typeof Chart === "undefined" || !topFeatures) return;

  if (featImportanceChartInstance) featImportanceChartInstance.destroy();

  const labels = topFeatures.map(f => f.feature.replace(/_/g, " "));
  const values = topFeatures.map(f => f.importance);

  featImportanceChartInstance = new Chart(canvas, {
    type: "bar",
    data: {
      labels: labels,
      datasets: [{
        label: "Importance Weight",
        data: values,
        backgroundColor: "rgba(139, 92, 246, 0.7)",
        borderColor: "#8b5cf6",
        borderWidth: 1,
        borderRadius: 4
      }]
    },
    options: {
      indexAxis: 'y',
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false }
      },
      scales: {
        x: {
          grid: { color: "rgba(255,255,255,0.05)" },
          ticks: { color: "#64748b" }
        },
        y: {
          grid: { display: false },
          ticks: { color: "#94a3b8", font: { size: 10 } }
        }
      }
    }
  });
}

// Active Alerts & Work Orders
async function loadAlertsData() {
  try {
    const res = await fetch("/api/alerts");
    if (!res.ok) return;
    const data = await res.json();

    const alertContainer = document.getElementById("alert-feed-container");
    alertContainer.innerHTML = "";

    if (data.alerts.length === 0) {
      alertContainer.innerHTML = `
        <div style="padding: 1.5rem; text-align: center; color: var(--text-muted); font-size: 0.88rem;">
          ✓ All industrial machines operating within safe parameters. No active failure alerts.
        </div>
      `;
    } else {
      data.alerts.forEach(a => {
        const card = document.createElement("div");
        const sevClass = a.severity.toLowerCase();
        card.className = `alert-card ${sevClass}`;

        card.innerHTML = `
          <div class="alert-info">
            <h4>
              <span>${a.machine_id}</span>
              <span class="status-badge ${sevClass}">${a.severity}</span>
              <span style="color: var(--accent-cyan)">${a.risk_score}% Risk</span>
            </h4>
            <p>${a.reason}</p>
            <p style="font-size: 0.75rem; color: var(--text-muted); margin-top: 0.2rem;">
              Action: ${a.recommended_action}
            </p>
          </div>
          <div style="display: flex; flex-direction: column; align-items: flex-end; gap: 0.5rem;">
            <span class="alert-time">${a.timestamp}</span>
            <button class="btn-primary" style="padding: 0.35rem 0.85rem; font-size: 0.78rem;" onclick="openWorkOrderModal('${a.machine_id}')">
              Dispatch Work Order
            </button>
          </div>
        `;
        alertContainer.appendChild(card);
      });
    }

    // Work Orders list
    const woContainer = document.getElementById("work-orders-container");
    if (data.work_orders && data.work_orders.length > 0) {
      woContainer.innerHTML = "";
      data.work_orders.forEach(wo => {
        const item = document.createElement("div");
        item.style.background = "rgba(255,255,255,0.03)";
        item.style.border = "1px solid var(--border-color)";
        item.style.borderRadius = "var(--radius-sm)";
        item.style.padding = "0.85rem";
        item.innerHTML = `
          <div style="display: flex; justify-content: space-between; font-size: 0.82rem; font-weight: 600;">
            <span style="color: var(--accent-cyan);">${wo.order_id} • ${wo.machine_id}</span>
            <span class="status-badge warning">${wo.status}</span>
          </div>
          <p style="font-size: 0.78rem; color: var(--text-secondary); margin: 0.3rem 0;">${wo.scope}</p>
          <div style="display: flex; justify-content: space-between; font-size: 0.72rem; color: var(--text-muted);">
            <span>Assigned: ${wo.technician}</span>
            <span>${wo.created_at}</span>
          </div>
        `;
        woContainer.appendChild(item);
      });
    }

  } catch (err) {
    console.error("Alerts load error:", err);
  }
}

// Work Order Modal
function openWorkOrderModal(machineId) {
  document.getElementById("wo-machine-id").value = machineId;
  document.getElementById("modal-wo-title").textContent = `Dispatch Preventive Work Order: ${machineId}`;
  document.getElementById("modal-work-order").classList.add("open");
}

function closeWorkOrderModal() {
  document.getElementById("modal-work-order").classList.remove("open");
}

async function handleWorkOrderSubmit(e) {
  e.preventDefault();
  const machineId = document.getElementById("wo-machine-id").value;
  const technician = document.getElementById("wo-technician").value;
  const priority = document.getElementById("wo-priority").value;

  try {
    const res = await fetch("/api/alerts/dispatch", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ machine_id: machineId, technician, priority })
    });
    const data = await res.json();
    closeWorkOrderModal();
    showToast(`Work Order ${data.work_order.order_id} dispatched for ${machineId}!`, "success");
    loadFleetData();
  } catch (err) {
    console.error("Error dispatching work order:", err);
  }
}

// Anomaly Injection
function openInjectModal() {
  document.getElementById("modal-inject-anomaly").classList.add("open");
}

function closeInjectModal() {
  document.getElementById("modal-inject-anomaly").classList.remove("open");
}

async function handleInjectAnomalySubmit(e) {
  e.preventDefault();
  const machineId = document.getElementById("inject-target-machine").value;
  const anomalyType = document.getElementById("inject-anomaly-mechanism").value;

  try {
    const res = await fetch("/api/inject_anomaly", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ machine_id: machineId, anomaly_type: anomalyType })
    });
    const data = await res.json();
    closeInjectModal();
    showToast(data.message, "warning");
    
    // Refresh fleet and focus on that machine
    await loadFleetData();
    selectedMachineId = machineId;
    loadMachineTelemetry(machineId);

  } catch (err) {
    console.error("Inject anomaly error:", err);
  }
}

// Reset Machine to Baseline
async function resetMachineToBaseline(machineId) {
  try {
    const res = await fetch("/api/reset_machine", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ machine_id: machineId })
    });
    const data = await res.json();
    showToast(`Machine ${machineId} overhauled. Baseline restored.`, "success");
    await loadFleetData();
    loadMachineTelemetry(machineId);
  } catch (err) {
    console.error("Reset error:", err);
  }
}

// Toast Helper
function showToast(message, type = "info") {
  const container = document.getElementById("toast-container");
  const toast = document.createElement("div");
  toast.className = `toast toast-${type}`;
  
  let icon = "ℹ";
  if (type === "success") icon = "✓";
  if (type === "warning") icon = "⚠";

  toast.innerHTML = `<span style="font-weight: 700;">${icon}</span> <span>${message}</span>`;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = "0";
    toast.style.transform = "translateX(100%)";
    toast.style.transition = "all 0.3s ease";
    setTimeout(() => toast.remove(), 300);
  }, 4000);
}
