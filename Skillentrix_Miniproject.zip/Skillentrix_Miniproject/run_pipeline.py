#!/usr/bin/env python
"""
Command-line runner for the Industrial Predictive Maintenance Pipeline.
Usage:
    python run_pipeline.py [--machines 10] [--days 180] [--window 24]
"""

import argparse
from src.pipeline import run_predictive_maintenance_pipeline

def main():
    parser = argparse.ArgumentParser(description="Predictive Maintenance for Industrial Equipment Pipeline")
    parser.add_argument("--machines", type=int, default=10, help="Number of industrial machines to simulate")
    parser.add_argument("--days", type=int, default=180, help="Number of days of hourly telemetry data")
    parser.add_argument("--window", type=int, default=24, help="Failure prediction lead-time window in hours (default: 24h)")
    parser.add_argument("--split", type=float, default=0.75, help="Temporal train-test split ratio (default: 0.75)")
    
    args = parser.parse_args()
    
    run_predictive_maintenance_pipeline(
        num_machines=args.machines,
        days=args.days,
        prediction_window_hours=args.window,
        temporal_split_ratio=args.split
    )

if __name__ == "__main__":
    main()
