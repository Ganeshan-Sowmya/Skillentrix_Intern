# Sentinel-AI: Predictive Maintenance for Industrial Equipment
### End-to-End Machine Learning System for Failure Lead-Time Prediction & Condition Monitoring

[![Python 3.10+](https://img.shields.io/badge/Python-3.10+-3776AB?style=flat&logo=python&logoColor=white)](https://python.org)
[![Scikit-Learn](https://img.shields.io/badge/Scikit--Learn-1.0+-F7931E?style=flat&logo=scikit-learn&logoColor=white)](https://scikit-learn.org)
[![Flask](https://img.shields.io/badge/Flask-Web%20Dashboard-000000?style=flat&logo=flask&logoColor=white)](https://flask.palletsprojects.com)
[![PR-AUC](https://img.shields.io/badge/Test%20PR--AUC-0.9987-brightgreen?style=flat)](#)
[![Recall](https://img.shields.io/badge/Failure%20Recall-99.0%25-success?style=flat)](#)
[![ROI](https://img.shields.io/badge/Operational%20Savings-$869k%20(664%25%20ROI)-blueviolet?style=flat)](#)

---

## 1. Executive Summary & Problem Formulation

In modern manufacturing, unexpected machinery breakdowns (e.g. CNC spindles, centrifugal pumps, hydraulic presses, compressors) lead to catastrophic operational costs, production line shutdowns, and worker safety hazards. Traditional **run-to-failure** maintenance is expensive, while rigid **calendar-based preventive maintenance** frequently over-services equipment prematurely.

**Sentinel-AI** is a production-grade predictive maintenance platform that predicts whether an industrial asset is likely to experience a failure breakdown within a future **24-hour lead-time window**. By alerting maintenance engineers ahead of time, replacement parts and repairs can be scheduled during planned shifts at a fraction of the breakdown cost.

---

## 2. Technical Architecture & Approach

The project strictly follows the 6-step industrial predictive maintenance methodology:

```
[Raw Sensors] Temperature, Vibration RMS, Pressure, Operating Hours, Lubricant Level
      │
      ▼
[Step 1: Ingestion & Telemetry Generator] (Physical bearing degradation & thermal runaway models)
      │
      ▼
[Step 2: Causal Feature Engineering] (Backward-looking rolling stats, lags, volatility - 0% leakage)
      │
      ▼
[Step 3: Prediction Window & Labeling] (24h lead-time window: Y(t) = 1 if failure in (t, t+24h])
      │
      ▼
[Step 4: Imbalanced Learning Pipeline] (Random Forest, HistGradientBoosting, LogisticRegression with class_weight='balanced')
      │
      ▼
[Step 5: Temporal Evaluation & Cost Matrix] (PR-AUC: 0.9987, Recall: 99.0%, Precision: 94.3%, False Alarms: 0.08%)
      │
      ▼
[Step 6: SCADA-Grade Monitoring Dashboard] (Real-time risk scores, What-If simulator, Chart.js telemetry, Alert Dispatcher)
```

### Step 1: Timestamped Industrial Sensor Ingestion & Simulation
- **Machines Monitored**: 10 industrial assets (CNC Mills, Centrifugal Pumps, Hydraulic Presses, Compressors, Turbine Generators) across factory zones.
- **Multivariate Telemetry**:
  - `vibration`: RMS velocity (mm/s) according to ISO 10816 standards.
  - `temperature`: Component bearing/casing temperature (°C).
  - `pressure`: Hydraulic/circuit pressure (PSI).
  - `operational_load`: Normalized machine capacity utilization (0.4 to 1.05).
  - `ambient_temp`: Diurnal environmental temperature cycle.
  - `lubrication_level`: Fluid quality and viscosity degradation score (0-100%).
  - `operating_hours` & `hours_since_last_service`: Fatigue counters.
- **Realistic Failure Physics**: Simulates exponential bearing race spalling, thermal dissipation runaway, and valve seal blowouts.

### Step 2: Causal Feature Engineering (Zero Future Leakage)
In time-series machine learning, using centered or forward-looking rolling windows introduces catastrophic data leakage. Sentinel-AI guarantees strict causal ordering:
- **Rolling Windows**: 3-hour, 12-hour, and 24-hour backward-looking windows (`closed='right'`).
  - Rolling mean $\mu_{3h}, \mu_{12h}, \mu_{24h}$ (baseline trend).
  - Rolling standard deviation $\sigma_{3h}, \sigma_{12h}, \sigma_{24h}$ (instability & micro-flutter).
  - Rolling min, max, and peak-to-peak range (crest factor proxy).
- **Temporal Lags & Derivatives**:
  - Lag values: $X_{t-1h}$, $X_{t-3h}$.
  - Differentials (first derivative): $X_t - X_{t-1h}$, $X_t - X_{t-3h}$.
  - Acceleration (second derivative): rate of degradation intensification.
- **Cross-Sensor Domain Stress Features**:
  - `vib_to_load_ratio`: Vibration per unit load (high vibration at low load signals mechanical looseness).
  - `temp_above_ambient`: Direct thermal friction dissipation delta.
  - `pressure_deviation_24h`: Hydraulic drift against rolling baseline.
  - `service_stress_index`: $\ln(1 + \text{service\_hours}) \times \text{vibration}$.

### Step 3: Failure Prediction Horizon & Target Labeling
Given failure timestamp $T_{\text{failure}}$ and prediction window $W = 24\text{ hours}$:
$$Y(t) = \begin{cases} 1 & \text{if } \exists T_{\text{failure}} \in (t, t + W] \\ 0 & \text{otherwise} \end{cases}$$
- This formulation gives plant engineers an operational lead-time window of 24 hours to intercept failures.
- Highly imbalanced distribution: ~2.0% positive failure window observations out of 28,800 telemetry records.

### Step 4: Classification Modeling & Imbalance Handling
- **Temporal Train-Test Split**: Chronological split at 75% mark (first 90 days train, subsequent 30 days held-out out-of-time test). Zero shuffling across time.
- **Rare Event Handling**: Models trained with `class_weight='balanced'` to prevent majority class bias.
- **Models Benchmarked**:
  1. **Random Forest Classifier (Champion)**: 100 decision trees, depth 12, balanced weights.
  2. **Histogram Gradient Boosting Classifier**: Fast gradient-boosted trees with weighted loss.
  3. **Logistic Regression**: Scaled linear baseline with inverse class frequency weights.

### Step 5: Evaluation & Cost-Benefit Analysis
Standard accuracy is deceptive on 98:2 imbalanced datasets. We evaluate:
- **PR-AUC (Precision-Recall Area Under Curve)**: Measures precision across all recall thresholds on imbalanced data.
- **False Alarm Rate**: Minimizes unnecessary maintenance crew dispatches.
- **Industrial Cost Matrix**:
  - Unplanned breakdown: $\$10,000$
  - Planned preventive overhaul: $\$1,200$
  - False alarm inspection: $\$350$

| Metric | Champion Model (Random Forest) |
|---|---|
| **Test PR-AUC** | **0.9987** |
| **Failure Recall** | **99.0%** (99 of 100 failure windows detected) |
| **Alarm Precision** | **94.3%** |
| **False Alarms** | **6** across 7,100 normal test hours (0.08% false alarm rate) |
| **Run-to-Failure Baseline Cost** | $\$1,000,000.00$ |
| **Sentinel-AI Operational Cost** | $\$130,900.00$ |
| **Net Financial Savings** | **$+\$869,100.00$ (664% ROI)** |

**Top Predictive Features**:
1. `vibration_lag_1h` (12.4% importance)
2. `vibration_roll_std_12h` (9.9% importance - bearing flutter/volatility)
3. `vibration_roll_mean_3h` (9.1% importance)
4. `vibration_roll_max_12h` (8.3% importance)
5. `temperature_roll_std_24h` (3.9% importance)

### Step 6: SCADA-Grade Monitoring Dashboard & Web Application
- **Fleet Monitor Matrix**: Real-time status cards for all 10 machines, color-coded health gauges (Healthy green, Warning amber, Critical red with animated pulse).
- **Interactive Telemetry Visualizer**: Multi-sensor time-series graphs (Chart.js) with ISO 10816 threshold warning envelopes.
- **What-If Risk Simulator**: Interactive sliders for vibration, temperature, pressure, operating hours, and lubrication level with instantaneous model probability inference and prescription generation.
- **Active Alert Feed & Work Order Dispatch**: One-click maintenance work order generation with crew assignment and priority tracking.
- **Test Anomaly Injector**: Enables users to simulate sudden bearing wear or thermal breakdown on any live asset to watch alerts trigger in real time.

---

## 3. Project Directory Structure

```
Skillentrix_Miniproject/
│
├── data/
│   ├── raw/
│   │   ├── sensor_telemetry.csv        # 28,800 hourly records across 10 machines
│   │   ├── machine_metadata.csv        # Asset models, zones, power ratings, install dates
│   │   └── maintenance_history.csv     # 63 logged breakdown and preventive maintenance events
│   └── processed/
│       └── features_engineered.csv     # 78 engineered causal features
│
├── src/
│   ├── __init__.py
│   ├── data_generator.py               # Physics-based industrial multivariate telemetry simulator
│   ├── feature_engineering.py          # Backward-only rolling stats, lags, and stress metrics
│   ├── labeling.py                     # 24h prediction window labeling engine
│   ├── model_training.py               # Imbalanced classifier training & model selection
│   ├── evaluation.py                   # PR-AUC, ROC-AUC, confusion matrix & cost calculator
│   └── pipeline.py                     # Orchestrator linking raw data to trained artifacts
│
├── models/
│   ├── best_model.joblib               # Serialized champion model (RandomForest)
│   ├── feature_columns.json            # 72 predictor feature column schema
│   └── metrics_summary.json            # Full benchmark evaluation metrics & curves
│
├── static/
│   ├── css/
│   │   └── styles.css                  # Custom SCADA dark-mode theme & glassmorphism
│   └── js/
│       └── app.js                      # Real-time charts, polling, simulator, modals, toasts
│
├── templates/
│   └── index.html                      # SCADA Monitoring Center & Dashboard
│
├── tests/
│   ├── __init__.py
│   └── test_system.py                  # Automated integration test suite (8 tests)
│
├── app.py                              # Flask server with REST API endpoints
├── run_pipeline.py                     # CLI pipeline runner with configurable args
├── requirements.txt                    # Project dependencies
└── README.md                           # Documentation
```

---

## 4. Getting Started & Installation

### Prerequisites
- Python 3.10+
- pip

### Step 1: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 2: Run Automated Tests
Verify all API routes, feature generation, and model inference:
```bash
python tests/test_system.py
```
*(All 8 integration tests should pass with `OK`)*

### Step 3: Run the Machine Learning Pipeline (Optional Re-training)
To re-generate data, compute features, and re-train the models:
```bash
python run_pipeline.py --machines 10 --days 120 --window 24
```

### Step 4: Launch the Web Dashboard
Start the condition monitoring server:
```bash
python app.py
```
Open your browser and navigate to:
**`http://127.0.0.1:5000`**

---

## 5. Live Dashboard Features Guide

1. **Fleet Monitor Tab**:
   - High-level KPIs: Total Machines, Critical Equipment Count, Overall Fleet Health Index, and Total Cost Saved.
   - Individual machine cards showing real-time Vibration RMS, Temperature, Pressure, and hours remaining until predicted failure.
2. **Telemetry Analysis Tab**:
   - Select any machine (e.g. `M-101`) to inspect historical sensor trends over the past 72 hours.
   - Toggle between **Vibration**, **Temperature**, and **Pressure** charts with ISO safety limit threshold envelopes.
3. **What-If Risk Simulator Tab**:
   - Drag sliders for Vibration, Temperature, Pressure, Service Hours, and Lubricant Quality.
   - Click preset buttons (**Nominal**, **Bearing Wear**, **Thermal Runaway**) to immediately see model inference, failure risk gauge (0-100%), and tailored engineering recommendations.
4. **Model Benchmark & ROI Tab**:
   - Inspect the **Precision-Recall Curve (PR-AUC: 0.9987)**, **Feature Importances bar chart**, **Confusion Matrix**, and the **Operational Cost Savings calculation**.
5. **Active Alerts Tab & Work Orders**:
   - View high-risk machine alerts and click **Dispatch Work Order** to assign maintenance squads.
   - Use the **"+ Inject Test Anomaly"** header button to trigger an artificial bearing failure on any machine and watch the alert trigger live!

---

## 6. Mathematical & Domain References
- **ISO 10816-3**: Mechanical vibration evaluation standard for industrial machines.
- **Davis & Goadrich (2006)**: *The Relationship Between Precision-Recall and ROC Curves* (PR-AUC necessity in highly skewed classes).
- **NASA C-MAPSS**: Turbofan engine degradation simulation benchmark standards.
